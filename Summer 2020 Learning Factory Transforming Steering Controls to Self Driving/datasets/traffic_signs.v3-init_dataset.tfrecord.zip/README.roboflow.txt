
traffic_signs - v3 init_dataset
==============================

This dataset was exported via roboflow.ai on January 2, 2021 at 10:34 AM GMT

It includes 948 images.
Signs are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


